import 'package:flutter/material.dart';
import 'assistant_engine.dart';

void main() {
  runApp(const VoiceAssistantApp());
}

class VoiceAssistantApp extends StatelessWidget {
  const VoiceAssistantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Voice Assistant',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
        useMaterial3: true,
      ),
      home: const AssistantHome(),
    );
  }
}

class AssistantHome extends StatefulWidget {
  const AssistantHome({super.key});

  @override
  State<AssistantHome> createState() => _AssistantHomeState();
}

class _AssistantHomeState extends State<AssistantHome> {
  final AssistantEngine assistant = AssistantEngine();
  final TextEditingController controller = TextEditingController();
  String status = 'Ready';
  bool listening = false;

  @override
  void dispose() {
    assistant.dispose();
    controller.dispose();
    super.dispose();
  }

  Future<void> runCommand([String? text]) async {
    final command = (text ?? controller.text).trim();
    if (command.isEmpty) return;

    setState(() => status = 'Working...');
    final response = await assistant.execute(command);

    setState(() {
      status = response;
      controller.clear();
    });
    await assistant.speak(response);
  }

  Future<void> listen() async {
    if (listening) return;

    setState(() {
      listening = true;
      status = 'Listening...';
    });

    final text = await assistant.listen();

    setState(() {
      listening = false;
      controller.text = text;
      status = text.isEmpty ? 'I did not hear anything.' : 'Command received';
    });

    if (text.isNotEmpty) {
      await runCommand(text);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Voice Assistant'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const Text(
              'What would you like me to do?',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 25),
            GestureDetector(
              onTap: listen,
              child: CircleAvatar(
                radius: 72,
                child: Icon(
                  listening ? Icons.mic : Icons.mic_none,
                  size: 70,
                ),
              ),
            ),
            const SizedBox(height: 18),
            Text(status, textAlign: TextAlign.center),
            const SizedBox(height: 25),
            TextField(
              controller: controller,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => runCommand(),
              decoration: InputDecoration(
                hintText: 'Type a command instead',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: runCommand,
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Try saying:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 8),
            for (final example in const [
              'Create a folder called August Invoices',
              'Create invoice 0049 for Newton',
              'Write an email saying the order is ready',
              'Find my latest invoice',
            ])
              ListTile(
                dense: true,
                leading: const Icon(Icons.arrow_forward_ios, size: 14),
                title: Text(example),
                onTap: () => runCommand(example),
              ),
          ],
        ),
      ),
    );
  }
}
