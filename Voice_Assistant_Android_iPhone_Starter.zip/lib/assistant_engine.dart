import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class AssistantEngine {
  final SpeechToText _speech = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  Future<String> listen() async {
    final available = await _speech.initialize();
    if (!available) {
      return 'Voice recognition is not available on this device.';
    }

    String result = '';
    await _speech.listen(
      onResult: (value) => result = value.recognizedWords,
      listenFor: const Duration(seconds: 12),
      pauseFor: const Duration(seconds: 3),
    );

    await Future.delayed(const Duration(milliseconds: 500));
    await _speech.stop();
    return result;
  }

  Future<void> speak(String text) async {
    await _tts.setLanguage('en-ZA');
    await _tts.setSpeechRate(0.48);
    await _tts.speak(text);
  }

  Future<String> execute(String command) async {
    final c = command.toLowerCase().trim();

    // Folder/file commands — connect these to platform file APIs in V2.
    if (c.startsWith('create a folder') || c.startsWith('create folder')) {
      final name = command
          .replaceFirst(RegExp(r'(?i)^create a folder'), '')
          .replaceFirst(RegExp(r'(?i)^create folder'), '')
          .trim();
      return name.isEmpty
          ? 'What would you like the folder to be called?'
          : 'I understood: create the folder "$name". File-system integration is ready to be connected in the next build.';
    }

    if (c.contains('invoice') && c.contains('newton')) {
      return 'I understood this as a Clean Advanced Chemicals invoice command for Newton. The next build will connect this to the invoice generator and file storage.';
    }

    if (c.contains('email') || c.contains('e-mail')) {
      return 'I can prepare the email command. The next build will connect this to your email provider so I can compose and attach files.';
    }

    if (c.contains('latest invoice') || c.contains('find my invoice')) {
      return 'I can search for your invoices once phone file access is connected.';
    }

    return 'I heard: "$command". I can add a specific action for that command in the next version.';
  }

  void dispose() {
    _speech.stop();
    _tts.stop();
  }
}
