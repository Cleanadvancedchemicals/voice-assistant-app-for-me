# Voice Assistant App — Android + iPhone starter

This is a Flutter starter for a cross-platform voice-controlled assistant.

Included in this first version:
- Voice command input
- Voice-to-text
- Text-to-speech responses
- Command interpretation structure
- File/folder command placeholders
- Email command placeholders
- Clean Advanced Chemicals business command examples
- A simple, large-button mobile interface

Important:
Android and iOS restrict what an ordinary app can control in other apps. Full cross-app automation needs Android Accessibility/intent integrations and iOS Shortcuts/App Intents. Those integrations should be added in the platform-specific layers rather than attempting to bypass OS security.

To run:
1. Install Flutter.
2. Run `flutter pub get`.
3. Connect an Android or iPhone.
4. Run `flutter run`.

This is a foundation, not yet a signed APK/IPA. A release build requires the appropriate Android/iOS development environment and signing.
