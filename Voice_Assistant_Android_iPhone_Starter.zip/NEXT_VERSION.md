# V2 roadmap

1. Android Accessibility Service for supported cross-app UI actions.
2. Android intents for launching supported apps/actions.
3. Android document/file picker and folder management.
4. iOS App Intents and Shortcuts actions.
5. Gmail/Outlook integration.
6. WhatsApp/share-sheet workflows where supported.
7. AI command parser with confirmation rules.
8. Clean Advanced Chemicals invoice generator.
9. Customer folders and document filing.
10. Optional wake phrase/quick action, subject to OS capabilities.
11. Secure settings for which actions require confirmation.
